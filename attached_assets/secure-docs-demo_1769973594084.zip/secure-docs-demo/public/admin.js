const docs = document.getElementById("docs");
const keyEl = document.getElementById("key");

function loadDocs() {
  fetch("/api/documents")
    .then(r => r.json())
    .then(list => {
      docs.innerHTML = "";
      list.forEach(d => {
        docs.innerHTML += `
          <tr>
            <td>${d.name}</td>
            <td>
              <button onclick="replaceDoc('${d.name}')">Edit</button>
              <button onclick="deleteDoc('${d.name}')">Delete</button>
            </td>
          </tr>`;
      });
    });
}

function uploadDoc() {
  const f = new FormData();
  f.append("file", file.files[0]);
  fetch("/api/documents", { method:"POST", body:f }).then(loadDocs);
}

function replaceDoc(name) {
  const i = document.createElement("input");
  i.type = "file";
  i.onchange = () => {
    const f = new FormData();
    f.append("file", i.files[0]);
    fetch(`/api/documents/${name}`, { method:"PUT", body:f }).then(loadDocs);
  };
  i.click();
}

function deleteDoc(name) {
  fetch(`/api/documents/${name}`, { method:"DELETE" }).then(loadDocs);
}

function regenKey() {
  fetch("/api/access-key/regenerate", { method:"POST" })
    .then(r => r.json())
    .then(d => keyEl.innerText = d.key);
}

function generateQR() {
  qrBox.innerHTML =
    `<img src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${location.origin}/public.html">`;
}

fetch("/api/access-key").then(r=>r.json()).then(d=>keyEl.innerText=d.key);
loadDocs();
