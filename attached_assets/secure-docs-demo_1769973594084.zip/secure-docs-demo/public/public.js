function auth() {
    fetch("/api/public/auth", {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body:JSON.stringify({ key:key.value })
    })
    .then(r=>r.json())
    .then(d=>{
      if(!d.success) return alert("Invalid key");
      loadDocs();
    });
  }
  
  function loadDocs() {
    fetch("/api/documents")
      .then(r=>r.json())
      .then(list=>{
        docs.innerHTML="";
        list.forEach(d=>{
          if(d.type==="pdf")
            docs.innerHTML += `<iframe src="${d.url}" height="600"></iframe>`;
          else
            docs.innerHTML += `<img src="${d.url}">`;
        });
      });
  }
  