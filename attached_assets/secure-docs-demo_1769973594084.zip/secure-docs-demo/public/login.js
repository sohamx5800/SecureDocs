function login() {
    fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: pwd.value })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) location.href = "/admin.html";
      else document.getElementById("error").innerText = "Wrong password";
    });
  }
  