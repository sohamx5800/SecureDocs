const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static("public"));
app.use("/uploads", express.static("uploads"));

const ADMIN_PASSWORD = "admin123";
let accessKey = crypto.randomBytes(3).toString("hex").toUpperCase();

if (!fs.existsSync("uploads")) fs.mkdirSync("uploads");

const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});
const upload = multer({ storage });

/* ---------- ADMIN AUTH ---------- */
app.post("/api/admin/login", (req, res) => {
  res.json({ success: req.body.password === ADMIN_PASSWORD });
});

/* ---------- ACCESS KEY ---------- */
app.get("/api/access-key", (req, res) => res.json({ key: accessKey }));

app.post("/api/access-key/regenerate", (req, res) => {
  accessKey = crypto.randomBytes(3).toString("hex").toUpperCase();
  res.json({ key: accessKey });
});

/* ---------- DOCUMENTS ---------- */
app.get("/api/documents", (req, res) => {
  const files = fs.readdirSync("uploads").map(file => ({
    name: file,
    url: `/uploads/${file}`,
    type: file.endsWith(".pdf") ? "pdf" : "image"
  }));
  res.json(files);
});

app.post("/api/documents", upload.single("file"), (req, res) => {
  res.json({ success: true });
});

app.put("/api/documents/:name", upload.single("file"), (req, res) => {
  const old = path.join("uploads", req.params.name);
  if (fs.existsSync(old)) fs.unlinkSync(old);
  res.json({ success: true });
});

app.delete("/api/documents/:name", (req, res) => {
  const filePath = path.join("uploads", req.params.name);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  res.json({ success: true });
});

/* ---------- PUBLIC AUTH ---------- */
app.post("/api/public/auth", (req, res) => {
  res.json({ success: req.body.key === accessKey });
});

app.listen(PORT, () =>
  console.log(`Server running at http://localhost:${PORT}`)
);
